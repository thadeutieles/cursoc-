﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C2_Aula3
{
    class Conta
    {
        public int Numero { get; set; }
        public double Saldo { get; protected set; }
        public Cliente Titular { get; set; }

        public Conta (int numero, double saldo, string titular)
        {
            this.Numero = numero;
            this.Saldo = saldo;
            this.Titular = new Cliente(titular);
        }

        public Conta ()
        {

        }

        public virtual void Depositar (double valor)
        {
            this.Saldo += valor;
        }

        public virtual void Sacar (double valor)
        {
            this.Saldo -= valor;
        }
    }
}
