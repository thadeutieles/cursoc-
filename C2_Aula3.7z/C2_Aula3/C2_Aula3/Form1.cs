﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C2_Aula3
{
    public partial class Form1 : Form
    {
        private Conta c;
        private Conta c1;
        private Conta c2;
        private Conta[] contas;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            c = new Conta(1, 250.0, "Victor");
            c1 = new Conta(2, 200.0, "Thadeu");
            c2 = new Conta(3, 230.0, "Larissa");

            contas = new Conta[3];
            contas[0] = c;
            contas[1] = c1;
            contas[2] = c2;

            foreach (Conta conta in contas)
            {
                comboContas.Items.Add(conta.Titular);
            }
        }

        private void botaoDepositar_Click(object sender, EventArgs e)
        {
            /*
            double valor = Convert.ToDouble(textoValor.Text);
            c.Depositar(valor);
            textoValor.Text = "";

            this.MostraConta();

            MessageBox.Show("Um depósito de " + valor + " reais foi efetuado na conta " + c.Numero);
            */
        }
        
        /*
        private void MostraConta (Conta c)
        {
            textoTitular.Text = c.Titular.Nome;
            textoSaldo.Text = Convert.ToString(c.Saldo);
            textoNumero.Text = Convert.ToString(c.Numero);
        }
        */
        
        private void botaoSacar_Click(object sender, EventArgs e)
        {
            /*
            double valor = Convert.ToDouble(textoValor.Text);
            c.Sacar(valor);
            textoValor.Text = "";

            this.MostraConta();

            MessageBox.Show("Um saque de " + valor + " reais foi efetuado na conta " + c.Numero);
            */
        }
        

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indiceSelecionado = comboContas.SelectedIndex;
            Conta contaSelecionada = contas[indiceSelecionado];

            textoTitular.Text = contaSelecionada.Titular.Nome;
            textoSaldo.Text = Convert.ToString(contaSelecionada.Saldo);
            textoNumero.Text = Convert.ToString(contaSelecionada.Numero);
        }
    }
}
