﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C2_Aula3
{
    class ContaPoupanca : Conta
    {
        public ContaPoupanca ()
        {

        }

        public override void Depositar(double valor)
        {
            this.Saldo += valor + 0.1;
        }

        public override void Sacar(double valor)
        {
            this.Saldo -= valor + 0.1;
        }

        public void CalcularRendimentos () { }
    }
}
