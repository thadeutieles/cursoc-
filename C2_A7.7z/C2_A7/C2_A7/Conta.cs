﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C2_A7
{
    class Conta
    {
        public int Numero { get; set; }
        public string Titular { get; set; }
        public double Saldo { get; protected set; }

        public Conta (int numero, string titular, double saldo)
        {
            Numero = numero;
            Titular = titular;
            Saldo = saldo;
        }

        public void Saca (double valorSaque)
        {
            Saldo -= valorSaque;
        }

        public void Deposita (double valorDeposito)
        {
            Saldo += valorDeposito;
        }
    }
}
