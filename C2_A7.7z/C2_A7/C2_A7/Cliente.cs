﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C2_A7
{
    class Cliente
    {
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public int Idade { get; set; }

        public Cliente (string nome, string cpf, int idade)
        {
            Nome = nome;
            Cpf = cpf;
            Idade = idade;
        }

        public Cliente (string nome)
        {
            Nome = nome;
        }
    }
}
