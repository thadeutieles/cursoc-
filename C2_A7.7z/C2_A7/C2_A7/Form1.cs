﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C2_A7
{
    public partial class Form1 : Form
    {
        Conta[] contas;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Conta c1 = new Conta(1, "Thadeu", 100);
            Conta c2 = new Conta(2, "Larissa", 200);

            contas = new Conta[2];
            contas[0] = c1;
            contas[1] = c2;

            foreach (Conta conta in contas)
            {
                comboContas.Items.Add(conta.Titular);
            }
        }

        private void comboContas_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indiceSelecionado = comboContas.SelectedIndex;
            Conta contaSelecionada = contas[indiceSelecionado];
            
            textoNumero.Text = Convert.ToString(contaSelecionada.Numero);
            textoNome.Text = contaSelecionada.Titular;
            textoSaldo.Text = Convert.ToString(contaSelecionada.Saldo);
        }
    }
}
